from bottle import get, post, static_file, run
from sys import argv


@get("/<name>")
def web(name):
    return static_file(name, root=".")

@post("/upload")
def upload():
	return static_file("P2L3.html", root=".")


run(host="127.0.0.1", port=argv[1])